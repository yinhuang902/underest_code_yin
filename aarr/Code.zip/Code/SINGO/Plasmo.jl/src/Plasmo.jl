# Plasmo Code
# Yankai Cao, Victor Zavala
# UW-Madison, 2016

module Plasmo
using JuMP
export NetModel, @addNode, getNode, @Linkingconstraint
export getparent, getchildren, getchildrenDict 
export Ipopt_solve
export PipsNlp_solve
export getsumobjectivevalue, RandomStochasticModel, StochasticModel, copyStoModel, copyNLStoModel, extensiveModel, extensiveNLModel,addnodemodel!, copyModel, copyNLModel, extensiveSimplifiedModel
using Base.Meta
using MathProgBase      
using Distributions

type NetData
    children::Vector{JuMP.Model}
    parent
    childrenDict::Dict{String, JuMP.Model}
end
NetData() = NetData(JuMP.Model[], nothing, Dict{String, JuMP.Model}())
#NetData() = NetData(nothing, Dict{String, JuMP.Model}())

function NetModel(buildType="serial")
    m = JuMP.Model()
    m.ext[:Net] = NetData()
    m.ext[:BuildType] = buildType
    m.ext[:linkingId] = []
    return m
end

function getNet(m::JuMP.Model)
    if haskey(m.ext, :Net)
        return m.ext[:Net]
    else
        error("This functionality is only available to NetModel")
    end
end

getparent(m::JuMP.Model)       = getNet(m).parent
getchildrenDict(m::JuMP.Model)     = getNet(m).childrenDict

getname(c::Symbol) = c
getname(c::Void) = ()
getname(c::Expr) = c.args[1]

function getchildren(m::JuMP.Model)
    if haskey(m.ext, :Net)
        return getNet(m).children
    else
        return []
    end
end

function getNode(m::JuMP.Model, modelname::String)
    if !haskey(getNet(m).childrenDict, modelname)
        error("No model with name $modelname")
    elseif getNet(m).childrenDict[modelname] === nothing
        error("Multiple models with name $modelname")
    else
        return getNet(m).childrenDict[modelname]
    end
end


function registermodel(m::JuMP.Model, modelname::String, value::JuMP.Model)
    if haskey(getNet(m).childrenDict, modelname)
        getNet(m).childrenDict[modelname] = nothing # indicate duplicate
        error("Multiple models with name $modelname")
    else
        getNet(m).childrenDict[modelname] = value
    end
end

macro Linkingconstraint(m, args...)
      expr = quote
      	  id_start = length($(m).linconstr) + 1
          @constraint($(m),$(args...))
	  id_end = length($(m).linconstr)
	  $(m).ext[:linkingId] = [$(m).ext[:linkingId]; id_start:id_end]   
      end
      return esc(expr)
end

macro addNode(m, node)
    if isa(node, Symbol)
       return quote       	    
    	   if haskey($(esc(node)).ext, :Net)
	        getNet($(esc(node))).parent = $(esc(m))
    	   else
		$(esc(node)).ext[:Net] = NetData(JuMP.Model[], $(esc(m)),Dict{Symbol, JuMP.Model}())
           end
	   push!(getNet($(esc(m))).children, $(esc(node)))
    	   registermodel($(esc(m)), string($(quot(node))), $(esc(node)))
       end
    else
	error("not supported")
    end
end

macro addNode(m, node, nodename)
       return quote
           if haskey($(esc(node)).ext, :Net)
                getNet($(esc(node))).parent = $(esc(m))
           else
                $(esc(node)).ext[:Net] = NetData(JuMP.Model[], $(esc(m)),Dict{Symbol, JuMP.Model}())
           end
           push!(getNet($(esc(m))).children, $(esc(node)))
           registermodel($(esc(m)), $(esc(nodename)), $(esc(node)))
       end
end


# functions from this line are all only for stochastic problems
function getsumobjectivevalue(m::JuMP.Model) 
	 children = getchildren(m)
         leafModelList = children
         modelList = [m; leafModelList]
	 objVal = 0
         for (idx,node) in enumerate(modelList)
	    objVal += node.objVal     
         end
	 return objVal
end


function StochasticModel(createModel, data)
    nscen = length(data)
    master=NetModel()
    node1 = createModel(data[1])
    nfirst = length(node1.ext[:firstVarsId])
    @variable(master, first[1:nfirst])
    for i in 1:nscen
    	node = createModel(data[i])
    	@addNode(master, node, "s$i")
	firstVarsId = node.ext[:firstVarsId]
	for j = 1:nfirst
	    if firstVarsId[j] > 0
	        @constraint(master, first[j] == Variable(node, firstVarsId[j]))
	    end			
	end	    
    end
end


function RandomStochasticModel(createModel, nscen=10, nfirst=5, nparam=5)
    srand(1234)	 
    master=NetModel()
    @variable(master, first[1:nfirst])
    firstVarsId = collect(1:nfirst)
    for i in 1:nscen
        node = createModel()
        @addNode(master, node, "s$i")
	firstVarsId = 1:nfirst
	node.ext[:firstVarsId] = firstVarsId
        for j = 1:nfirst
            if firstVarsId[j] > 0
                @constraint(master, first[j] == Variable(node, firstVarsId[j]))
            end
        end
	nmodified = 0
	for c in 1:length(node.linconstr)
	    con = node.linconstr[c]    	    
	    terms = con.terms
	    vars = terms.vars
	    varsId = zeros(Int, length(vars))
	    for k in 1:length(vars)
	    	varsId[k] = vars[k].col
	    end
	    varsId = sort(union(varsId))
	    if length(findin(varsId, firstVarsId)) == length(varsId)
	        continue
	    end
	    nmodified += 1
	    if nmodified >= nparam
	        break	    
	    end
	    if con.lb == con.ub
	    	con.lb = addnoise(con.lb)
                con.ub = con.lb
	    elseif con.lb == -Inf
	        con.ub = addnoise(con.ub)
	    else
	        con.lb = addnoise(con.lb)
            end	    
	end
	if nmodified < nparam
	    for c = 1:length(node.quadconstr)
                con = node.quadconstr[c]
                terms = con.terms
		aff = terms.aff
                vars = [terms.qvars1;terms.qvars2; aff.vars]
                varsId = zeros(Int, length(vars))
                for k in 1:length(vars)
                    varsId[k] = vars[k].col
                end
		varsId = sort(union(varsId))
                if length(findin(varsId, firstVarsId))  == length(varsId)
                    continue
                end
                nmodified += 1
                if nmodified >= nparam
                   break
                end
		aff.constant = addnoise(aff.constant)
	    end
	end
	if (i == 1) && (nmodified < nparam)
	    println("warning: the number of linear/quadratic second stage constraint  ", nmodified, " is less than nparam ",nparam) 	     
	end
    end
    return master
end


function addnoise(a)
    if a == 0
        d = Uniform(-10, 10)
        a = a + rand(d)      	 
    else
	d = Uniform(0.5, 2.0)
	a = a * rand(d)		 
    end
    return a
end


function extensiveNLModel(P::JuMP.Model)
        m = Model()
	m.ext[:v_map] = []
	children = getchildren(P)
	nscen = length(children)
	NLobj = false
	if P.nlpdata != nothing
	    if P.nlpdata.nlobj != nothing
	        NLobj = true
	    end	
	else    
	    for scen = 1:nscen		   
	    	node = children[scen]
	    	if node.nlpdata != nothing
		    if node.nlpdata.nlobj != nothing
		        NLobj = true
		        break
		    end
		end
            end	   
	end	
        num_vars = P.numCols
        #add the node model variables to the new model
        for i = 1:num_vars
            @variable(m,P.colLower[i] <= x <= P.colUpper[i])   #just call the new variable x
            var_name = string(Variable(P,i))
            setname(x,var_name)                            #rename the variable to the node model variable name plus the node or edge name
            setcategory(x, P.colCat[i])                            #set the variable to the same category
            setvalue(x, P.colVal[i])                               #set the variable to the same value
            m.varDict[Symbol(var_name)] = x
        end
        delete!(m.varDict,:x)


	m.obj = copy(P.obj, m)
        m.objSense = P.objSense
	for scen = 1:nscen
            modelname = "s$(scen)"
            node = children[scen]
            nodeobj = addnodeNLmodel!(m, node, modelname)	    
	    m.obj.qvars1 = [m.obj.qvars1; nodeobj.qvars1]
	    m.obj.qvars2 = [m.obj.qvars2; nodeobj.qvars2]
	    m.obj.qcoeffs = [m.obj.qcoeffs; nodeobj.qcoeffs]
	    m.obj.aff.vars = [m.obj.aff.vars; nodeobj.aff.vars]
	    m.obj.aff.coeffs = [m.obj.aff.coeffs; nodeobj.aff.coeffs]
	    m.obj.aff.constant += nodeobj.aff.constant
        end	

        d = JuMP.NLPEvaluator(m)     #Get the NLP evaluator object.  Initialize the expression graph
        MathProgBase.initialize(d, [:ExprGraph])
        expr = MathProgBase.obj_expr(d)
        JuMP.setNLobjective(m, P.objSense, expr)
	m.obj = zero(QuadExpr)

        m.linconstr  = [map(c->copy(c, m), P.linconstr); m.linconstr]
        for i = 1:length(P.linconstr)
            Pcon = P.linconstr[i]
            Pvars = Pcon.terms.vars
            mcon = m.linconstr[i]
            mvars = mcon.terms.vars

            for (j, Pvar) in enumerate(Pvars)
                if (Pvar.m != P)
                    scen = -1
                    for k in 1:length(children)
                        if Pvar.m == children[k]
                            scen = k
                        end
                    end
                    new_id =  m.ext[:v_map][scen][Pvar.col]
                    mvars[j] = Variable(m, new_id)
                end
            end
        end
	return m
end


function Base.copy(v::Array{Variable}, new_model::Model, indent::Int)
    ret = similar(v, Variable, size(v))
    for I in eachindex(v)
        ret[I] = Variable(new_model, v[I].col+indent)
    end
    ret
end

function Base.copy(v::Array{Variable}, new_model::Model, v_map::Array{Int, 1})
    ret = similar(v, Variable, size(v))
    for I in eachindex(v)
        ret[I] = Variable(new_model, v_map[v[I].col])
    end
    ret
end

function extensiveModel(P::JuMP.Model)
        m = Model()
	m.ext[:v_map] = []
        children = getchildren(P)
        nscen = length(children)
        NLobj = false
        if P.nlpdata != nothing
            if P.nlpdata.nlobj != nothing
                NLobj = true
            end
        else
            for scen = 1:nscen
                node = children[scen]
                if node.nlpdata != nothing
                    if node.nlpdata.nlobj != nothing
                        NLobj = true
                        break
                    end
                end
            end
        end
        num_vars = P.numCols
        #add the node model variables to the new model
        for i = 1:num_vars
            @variable(m,P.colLower[i] <= x <= P.colUpper[i])   #just call the new variable x
            var_name = string(Variable(P,i))
            setname(x,var_name)                            #rename the variable to the node model variable name plus the node or edge name
            setcategory(x, P.colCat[i])                            #set the variable to the same category
            setvalue(x, P.colVal[i])                               #set the variable to the same value
            m.varDict[Symbol(var_name)] = x
        end
        delete!(m.varDict,:x)

        m.obj = copy(P.obj, m)
        m.objSense = P.objSense
        for scen = 1:nscen
            modelname = "s$(scen)"
            node = children[scen]
            nodeobj = addnodemodel!(m, node, modelname)
            m.obj.qvars1 = [m.obj.qvars1; nodeobj.qvars1]
            m.obj.qvars2 = [m.obj.qvars2; nodeobj.qvars2]
            m.obj.qcoeffs = [m.obj.qcoeffs; nodeobj.qcoeffs]
            m.obj.aff.vars = [m.obj.aff.vars; nodeobj.aff.vars]
            m.obj.aff.coeffs = [m.obj.aff.coeffs; nodeobj.aff.coeffs]
            m.obj.aff.constant += nodeobj.aff.constant
        end

        m.linconstr  = [map(c->copy(c, m), P.linconstr); m.linconstr]
        children = getchildren(P)
        for i = 1:length(P.linconstr)
            Pcon = P.linconstr[i]
            Pvars = Pcon.terms.vars
            mcon = m.linconstr[i]
            mvars = mcon.terms.vars
            for (j, Pvar) in enumerate(Pvars)
                if (Pvar.m != P)
		    scen = -1
                    for k in 1:length(children)
                        if Pvar.m == children[k]
                            scen = k
                        end
                    end
                    new_id =  m.ext[:v_map][scen][Pvar.col]
                    mvars[j] = Variable(m, new_id)
                end
            end
        end	
        return m
end


function extensiveSimplifiedModel(P::JuMP.Model)
    ncols_first = P.numCols
    scenarios = Plasmo.getchildren(P)
    for (idx,scenario) in enumerate(scenarios)
        scenario.ext[:firstVarsId] = zeros(Int, ncols_first)
        scenario.ext[:firstVarsId][1:end]= -1
    end
    for c in 1:length(P.linconstr)
        coeffs = P.linconstr[c].terms.coeffs
        vars   = P.linconstr[c].terms.vars
        firstVarId = 0
        for (it,ind) in enumerate(coeffs)
            if (vars[it].m) == P
                firstVarId = vars[it].col
                break
            end
        end
        for (it,ind) in enumerate(coeffs)
            if (vars[it].m) != P
               scenario = vars[it].m
               scenario.ext[:firstVarsId][firstVarId] = vars[it].col
            end
        end
    end
    for (idx,scenario) in enumerate(scenarios)
        firstVarsId = scenario.ext[:firstVarsId]
	for i in 1:ncols_first
            if firstVarsId[i] > 0
                if scenario.colLower[firstVarsId[i]] >  P.colLower[i]
                    P.colLower[i] = scenario.colLower[firstVarsId[i]]
                end
                if scenario.colUpper[firstVarsId[i]] <  P.colUpper[i]
                    P.colUpper[i] = scenario.colUpper[firstVarsId[i]]
                end
            end
        end
    end

        m = Model()
	m.ext[:v_map] = []
        NLobj = false
        children = getchildren(P)
        nscen = length(children)
        NLobj = false
        if P.nlpdata != nothing
            if P.nlpdata.nlobj != nothing
                NLobj = true
            end
        else
            for scen = 1:nscen
                node = children[scen]
                if node.nlpdata != nothing
                    if node.nlpdata.nlobj != nothing
                        NLobj = true
                        break
                    end
                end
            end
        end

        num_vars = P.numCols
        #add the node model variables to the new model
        for i = 1:num_vars
            @variable(m,P.colLower[i] <= x <= P.colUpper[i])   #just call the new variable x
            var_name = string(Variable(P,i))
            setname(x,var_name)				       #rename the variable to the node model variable name plus the node or edge name
            setcategory(x, P.colCat[i])                        #set the variable to the same category
            setvalue(x, P.colVal[i])                           #set the variable to the same value
            m.varDict[Symbol(var_name)] = x
        end
        delete!(m.varDict,:x)

	m.obj = copy(P.obj, m)
        m.objSense = P.objSense

	children = getchildren(P)
	nscen = length(children)
	ncols = Array(Int, nscen+1)
	nlinconstrs = Array(Int, nscen+1)
	ncols[1] = m.numCols
	nlinconstrs[1] = length(m.linconstr)
	for scen in 1:nscen
	    node = children[scen]
	    modelname = "s$(scen)"
            nodeobj = addnodeSimplifiedmodel!(m, node, modelname, scen)
            m.obj.qvars1 = [m.obj.qvars1; nodeobj.qvars1]
            m.obj.qvars2 = [m.obj.qvars2; nodeobj.qvars2]
            m.obj.qcoeffs = [m.obj.qcoeffs; nodeobj.qcoeffs]
            m.obj.aff.vars = [m.obj.aff.vars; nodeobj.aff.vars]
            m.obj.aff.coeffs = [m.obj.aff.coeffs; nodeobj.aff.coeffs]
            m.obj.aff.constant += nodeobj.aff.constant
	    ncols[scen + 1] = m.numCols
	    nlinconstrs[scen + 1] = length(m.linconstr)
	end
	m.ext[:ncols] = ncols
	m.ext[:nlinconstrs] = nlinconstrs
	return m    
end


function addnodeSimplifiedmodel!(m::JuMP.Model,node::JuMP.Model, nodename, scen)
        old_numCols = m.numCols
        num_vars = node.numCols
	firstVarsId = node.ext[:firstVarsId] 

        v_map = Array(Int, num_vars)		#this dict will map linear index of the node model variables to the new model JuMP variables {index => JuMP.Variable}
        #add the node model variables to the new model
        for i = 1:num_vars
	    first = findin(firstVarsId, i);
	    if length(first) == 0    	    
                @variable(m,node.colLower[i] <= x <= node.colUpper[i])   #just call the new variable x
            	var_name = string(Variable(node,i)) 
            	setname(x,nodename*var_name)                              #rename the variable to the node model variable name plus the node or edge name
            	setcategory(x, node.colCat[i])                            #set the variable to the same category
            	setvalue(x,node.colVal[i])                                #set the variable to the same value
            	v_map[i] = x.col                                              #map the linear index of the node model variable to the new variable
            	m.varDict[Symbol(nodename*var_name)] = x
	    else
		v_map[i] = first[1]
	    end
        end
        delete!(m.varDict,:x)
	push!(m.ext[:v_map], v_map)

        for i = 1:length(node.linconstr)
	    con = copy(node.linconstr[i], node)
	    varsId = extractVarsId(con.terms.vars)
	    # if it is a first stage constraints (a constraints has only only first stage variables)
	    if length(findin(varsId, firstVarsId))  == length(varsId) && scen != 1
	        continue
	    end
	    con.terms.vars = copy(con.terms.vars, m, v_map)
	    m.linconstr = [m.linconstr; con]
        end

        for i = 1:length(node.quadconstr)
            con = copy(node.quadconstr[i], node)
            terms = con.terms
            varsId = extractVarsId([terms.qvars1;terms.qvars2;terms.aff.vars])
            if length(findin(varsId, firstVarsId))  == length(varsId) && scen	!= 1
                continue
            end
            terms.qvars1 = copy(terms.qvars1, m, v_map)
            terms.qvars2 = copy(terms.qvars2, m, v_map)
            terms.aff.vars = copy(terms.aff.vars, m, v_map)
            m.quadconstr = [m.quadconstr; con]
        end

        #Copy the non-linear constraints to the new model
        d = JuMP.NLPEvaluator(node)         #Get the NLP evaluator object.  Initialize the expression graph
        MathProgBase.initialize(d,[:ExprGraph])
        num_cons = MathProgBase.numconstr(node)
        for i = (1+length(node.linconstr)+length(node.quadconstr)):num_cons
            if !(MathProgBase.isconstrlinear(d,i))    #if it's not a linear constraint
                expr = MathProgBase.constr_expr(d,i)  #this returns a julia expression
            	varsId = extractVarsId(expr)
            	if length(findin(varsId, firstVarsId))  == length(varsId) && scen != 1
                    continue
                end
                _splicevars!(expr,v_map)              #splice the variables from v_map into the expression
                JuMP.addNLconstraint(m,expr)          #raw expression input for non-linear constraint
            end
        end
        nodeobj = copy(node.obj)
        nodeobj.qvars1 = copy(nodeobj.qvars1, m, v_map)
        nodeobj.qvars2 = copy(nodeobj.qvars2, m, v_map)
        nodeobj.aff.vars = copy(nodeobj.aff.vars, m, v_map)
        return nodeobj
end




function addnodemodel!(m::JuMP.Model,node::JuMP.Model, nodename)
        old_numCols = m.numCols
        num_vars = node.numCols
        v_map = Array(Int, num_vars)               #this dict will map linear index of the node model variables to the new model JuMP variables {index => JuMP.Variable}
        #add the node model variables to the new model
        for i = 1:num_vars
            @variable(m,node.colLower[i] <= x <= node.colUpper[i])   #just call the new variable x
            var_name = string(Variable(node,i))
            setname(x,nodename*var_name)                             #rename the variable to the node model variable name plus the node or edge name
            setcategory(x, node.colCat[i])                            #set the variable to the same category
            setvalue(x,node.colVal[i])                               #set the variable to the same value
            v_map[i] = x.col                                         #map the linear index of the node model variable to the new variable
            m.varDict[Symbol(nodename*var_name)] = x
        end
        delete!(m.varDict,:x)
	push!(m.ext[:v_map], v_map)

        for i = 1:length(node.linconstr)
	    con	= copy(node.linconstr[i], node)
            con.terms.vars = copy(con.terms.vars, m, v_map)
            m.linconstr	   = [m.linconstr; con]
        end

	for i = 1:length(node.quadconstr)
            con = copy(node.quadconstr[i], node)
	    terms = con.terms
            terms.qvars1 = copy(terms.qvars1, m, old_numCols)
            terms.qvars2 = copy(terms.qvars2, m, old_numCols)
            terms.aff.vars = copy(terms.aff.vars, m, old_numCols)
	    m.quadconstr = [m.quadconstr; con]
	end

        #Copy the non-linear constraints to the new model
        d = JuMP.NLPEvaluator(node)         #Get the NLP evaluator object.  Initialize the expression graph
        MathProgBase.initialize(d,[:ExprGraph])
        num_cons = MathProgBase.numconstr(node)
        for i = (1+length(node.linconstr)+length(node.quadconstr)):num_cons
            if !(MathProgBase.isconstrlinear(d,i))    #if it's not a linear constraint
                expr = MathProgBase.constr_expr(d,i)  #this returns a julia expression
                _splicevars!(expr,v_map)              #splice the variables from v_map into the expression
                JuMP.addNLconstraint(m,expr)          #raw expression input for non-linear constraint
            end
        end
        nodeobj = copy(node.obj)
        nodeobj.qvars1 = copy(nodeobj.qvars1, m, old_numCols)
        nodeobj.qvars2 = copy(nodeobj.qvars2, m, old_numCols)
        nodeobj.aff.vars = copy(nodeobj.aff.vars, m, old_numCols)
        return nodeobj
end


function addnodeNLmodel!(m::JuMP.Model,node::JuMP.Model, nodename)
	#= 
        node_numCols = node.numCols
	old_numCols = m.numCols
    	m.numCols += node.numCols
    	m.colNames = [m.colNames; node.colNames[:]]
    	m.colNamesIJulia = [m.colNamesIJulia; node.colNamesIJulia[:]]
    	m.colLower = [m.colLower; node.colLower[:]]
    	m.colUpper = [m.colUpper; node.colUpper[:]]
    	m.colCat = [m.colCat; node.colCat[:]]
    	m.colVal = [m.colVal; node.colVal[:]]
    	for (symb,v) in node.varDict
            m.varDict[Symbol(nodename*string(symb))] = copy(v, m)
        end
    	# Constraints
    	#m.linconstr  = [m.linconstr; map(c->copy(c, m), node.linconstr)]
    	#m.quadconstr = [m.quadconstr; map(c->copy(c, m), node.quadconstr)]
	v_map = Dict()        #this dict will map linear index of the node model variables to the new model JuMP variables {index => JuMP.Variable}
        for i = 1:node_numCols
            v_map[i] = Variable(m, i+old_numCols)
        end
	push!(m.ext[:v_map], v_map)

        for i = 1:length(node.linconstr)
            con = node.linconstr[i]
            t = collect(linearterms(con.terms))
            @constraint(m, con.lb <= sum{t[i][1]*v_map[linearindex(t[i][2])],i = 1:length(t)} + con.terms.constant <= con.ub)
        end
	=#

	old_numCols = m.numCols
        num_vars = node.numCols
        v_map = Array(Int, num_vars)        #this dict will map linear index of the node model variables to the new model JuMP variables {index => JuMP.Variable}
        #add the node model variables to the new model
        for i = 1:num_vars
            @variable(m,node.colLower[i] <= x <= node.colUpper[i])   #just call the new variable x
            var_name = string(Variable(node,i))
            setname(x,nodename*var_name)                            #rename the variable to the node model variable name plus the node or edge name
            setcategory(x, node.colCat[i])                            #set the variable to the same category
            setvalue(x,node.colVal[i])                               #set the variable to the same value
            v_map[i] = x.col                                             #map the linear index of the node model variable to the new variable
            m.varDict[Symbol(nodename*var_name)] = x
        end
        delete!(m.varDict,:x)
	push!(m.ext[:v_map], v_map)


        for i = 1:length(node.linconstr)
	    con	= copy(node.linconstr[i], node)
            con.terms.vars = copy(con.terms.vars, m, v_map)
            m.linconstr	   = [m.linconstr; con]
        end

        #Copy the non-linear constraints to the new model
        d = JuMP.NLPEvaluator(node)         #Get the NLP evaluator object.  Initialize the expression graph
        MathProgBase.initialize(d,[:ExprGraph])
        num_cons = MathProgBase.numconstr(node)
        for i = 1:num_cons
            if !(MathProgBase.isconstrlinear(d,i))    #if it's not a linear constraint
                expr = MathProgBase.constr_expr(d,i)  #this returns a julia expression
                _splicevars!(expr,v_map)              #splice the variables from v_map into the expression
                JuMP.addNLconstraint(m,expr)          #raw expression input for non-linear constraint
            end
        end
	
        nodeobj = copy(node.obj)
	nodeobj.qvars1 = copy(nodeobj.qvars1, m, old_numCols)
	nodeobj.qvars2 = copy(nodeobj.qvars2, m, old_numCols)
	nodeobj.aff.vars = copy(nodeobj.aff.vars, m, old_numCols)	
	return nodeobj
	#=
        # Objective
        m.obj = copy(node.obj, m)
        m.objSense = node.objSense
        num_vars = node.numCols
	v_map = Array(Int, num_vars)              #this dict will map linear index of the node model variables to the new model JuMP variables {index => JuMP.Variable}
        #add the node model variables to the new model
        for i = 1:num_vars
            @variable(m,node.colLower[i] <= x <= node.colUpper[i])   #just call the new variable x
            var_name = string(Variable(node,i))
            setname(x,node.name*var_name)		             #rename the variable to the node model variable name plus the node or edge name
            setcategory(x,node.colCat[i])                            #set the variable to the same category
            setvalue(x,node.colVal[i])                               #set the variable to the same value
            v_map[i] = x                                             #map the linear index of the node model variable to the new variable
            m.varDict[Symbol(node.name*var_name)] = x
        end
        delete!(m.varDict,:x)
        #copy the linear constraints to the new model
	for i = 1:length(node.linconstr)
            con = node.linconstr[i]
            t = collect(linearterms(con.terms))
            @constraint(m,reference,con.lb <= sum{t[i][1]*v_map[linearindex(t[i][2])],i = 1:length(t)} + con.terms.constant <= con.ub)
            push!(constraints(node),reference)
        end
        #Copy the non-linear constraints to the new model
        d = JuMP.NLPEvaluator(node)         #Get the NLP evaluator object.  Initialize the expression graph
        MathProgBase.initialize(d,[:ExprGraph])
        num_cons = MathProgBase.numconstr(node)
        for i = 1:num_cons
            if !(MathProgBase.isconstrlinear(d,i))    #if it's not a linear constraint
                expr = MathProgBase.constr_expr(d,i)  #this returns a julia expression
                _splicevars!(expr,v_map)              #splice the variables from v_map into the expression
                JuMP.addNLconstraint(m,expr)          #raw expression input for non-linear constraint
            end
        end
	=#
end


function copyModel(P::JuMP.Model)
    m = Model()	
    # Variables
    m.numCols = P.numCols
    m.colNames = P.colNames[:]
    m.colNamesIJulia = P.colNamesIJulia[:]
    m.colLower = P.colLower[:]
    m.colUpper = P.colUpper[:]
    m.colCat = P.colCat[:]
    m.colVal = P.colVal[:]
    m.linconstrDuals = P.linconstrDuals[:]
    m.redCosts = P.redCosts[:]
    m.varDict = Dict{Symbol,Any}()
    for (symb,v) in P.varDict
        m.varDict[symb] = copy(v, m)
    end
    # Constraints
    m.linconstr  = map(c->copy(c, m), P.linconstr)
    m.quadconstr = map(c->copy(c, m), P.quadconstr)

    # Objective
    m.obj = copy(P.obj, m)
    m.objSense = P.objSense
    #Copy the non-linear constraints to the new model
    d = JuMP.NLPEvaluator(P)     #Get the NLP evaluator object.  Initialize the expression graph
    MathProgBase.initialize(d,[:ExprGraph])
    num_cons = MathProgBase.numconstr(P)
    for i = (1+length(P.linconstr)+length(P.quadconstr)):num_cons
            expr = MathProgBase.constr_expr(d,i)  #this returns a julia expression
            JuMP.addNLconstraint(m,expr)          #raw expression input for non-linear constraint
    end
    if P.nlpdata.nlobj != nothing  #|| MathProgBase.isobjquadratic(d)
        expr = MathProgBase.obj_expr(d)
	JuMP.setNLobjective(m, P.objSense, expr)
    end
    
    if !isempty(P.ext)
        m.ext = similar(P.ext)
        for (key, val) in P.ext
            m.ext[key] = try
                copy(P.ext[key])
            catch
                continue;  #error("Error copying extension dictionary. Is `copy` defined for all your user types?")
            end
        end
    end
    return m
end

function copyNLModel(P::JuMP.Model)  # copy model and convert quadratic consriants and obj to nonlinear
    m = Model()
    # Variables
    m.numCols = P.numCols
    m.colNames = P.colNames[:]
    m.colNamesIJulia = P.colNamesIJulia[:]
    m.colLower = P.colLower[:]
    m.colUpper = P.colUpper[:]
    m.colCat = P.colCat[:]
    m.colVal = P.colVal[:]
    m.linconstrDuals = P.linconstrDuals[:]
    m.redCosts = P.redCosts[:]
    m.varDict = Dict{Symbol,Any}()
    for (symb,v) in P.varDict
        m.varDict[symb] = copy(v, m)
    end
    # Constraints
    m.linconstr  = map(c->copy(c, m), P.linconstr)
    #m.quadconstr = map(c->copy(c, m), P.quadconstr)

    # Objective
    m.obj = copy(P.obj, m)
    m.objSense = P.objSense
    #Copy the non-linear constraints to the new model
    d = JuMP.NLPEvaluator(P)     #Get the NLP evaluator object.  Initialize the expression graph
    MathProgBase.initialize(d,[:ExprGraph])
    num_cons = MathProgBase.numconstr(P)
    for i = (1+length(P.linconstr)):num_cons
            expr = MathProgBase.constr_expr(d,i)  #this returns a julia expression
            JuMP.addNLconstraint(m,expr)          #raw expression input for non-linear constraint
    end
    if !MathProgBase.isobjlinear(d)  #isa(P.nlpdata.nlobj, NonlinearExprData) || MathProgBase.isobjquadratic(d)  #P.nlpdata.nlobj != nothing 
        expr = MathProgBase.obj_expr(d)
        JuMP.setNLobjective(m, P.objSense, expr)
    end
    if !isempty(P.ext)
        m.ext = similar(P.ext)
        for (key, val) in P.ext
            m.ext[key] = try
                copy(P.ext[key])
            catch
                continue;  #error("Error copying extension dictionary. Is `copy` defined for all your user types?")
            end
        end
    end
    return m
end


function copyStoModel(P::JuMP.Model)
    if haskey(P.ext, :Net)	 
        m = NetModel() 
	children = getchildren(P)
	nscen = length(children)
    	for scen = 1:nscen 
	    modelname = "s$(scen)" 
    	    nodecopy = copyModel(children[scen])    	
	    @addNode(m, nodecopy, modelname)   
        end
    	m.numCols = P.numCols
    	m.colNames = P.colNames[:]
    	m.colNamesIJulia = P.colNamesIJulia[:]
    	m.colLower = P.colLower[:]
    	m.colUpper = P.colUpper[:]
    	m.colCat = P.colCat[:]
    	m.colVal = P.colVal[:]
    	m.varDict = Dict{Symbol,Any}()
    	for (symb,v) in P.varDict
            m.varDict[symb] = copy(v, m)
        end		
	m.linconstr  = map(c->copy(c, m), P.linconstr)
	for i = 1:length(P.linconstr)
	    Pcon = P.linconstr[i]	
	    Pvars = Pcon.terms.vars
	    mcon = m.linconstr[i]
	    mvars = mcon.terms.vars 
            for (j, Pvar) in enumerate(Pvars)
                if (Pvar.m != P)
                    scen = -1
                    for k in 1:length(children)
                        if Pvar.m == children[k]
                            scen = k
                        end
                    end
		    mvars[j] = Variable(getchildren(m)[scen], Pvar.col)
                end
            end
        end
        m.obj = copy(P.obj, m)
    	m.objSense = P.objSense
    	#Copy the non-linear objective
	if P.nlpdata != nothing
    	if P.nlpdata.nlobj != nothing  # !isobjquadratic(d)&& ! isobjlinear(d)
	    removed = removeConnection(P)
            d = JuMP.NLPEvaluator(P)     #Get the NLP evaluator object.  Initialize the expression graph
            MathProgBase.initialize(d,[:ExprGraph])
            expr = MathProgBase.obj_expr(d)
            JuMP.setNLobjective(m, P.objSense, expr)
	    P.linconstr = [P.linconstr; removed]
    	end
	end
    else
	m = copy(P)	
    end
    return m
end



function copyNLStoModel(P::JuMP.Model)
    if haskey(P.ext, :Net)
        m = NetModel()
        children = getchildren(P)
	nscen =	 length(children)
        for scen = 1:nscen
	    modelname = "s$(scen)"
            nodecopy = copyNLModel(children[scen])
            @addNode(m, nodecopy, modelname)
        end
        m.numCols = P.numCols
        m.colNames = P.colNames[:]
        m.colNamesIJulia = P.colNamesIJulia[:]
        m.colLower = P.colLower[:]
        m.colUpper = P.colUpper[:]
        m.colCat = P.colCat[:]
        m.colVal = P.colVal[:]
        m.varDict = Dict{Symbol,Any}()
        for (symb,v) in P.varDict
            m.varDict[symb] = copy(v, m)
        end
        m.linconstr  = map(c->copy(c, m), P.linconstr)
        for i = 1:length(P.linconstr)
            Pcon = P.linconstr[i]
            Pvars = Pcon.terms.vars
            mcon = m.linconstr[i]
            mvars = mcon.terms.vars
            for (j, Pvar) in enumerate(Pvars)
                if (Pvar.m != P)
                    scen = -1
                    for k in 1:length(children)
                        if Pvar.m == children[k]
                            scen = k
                        end
                    end
		    mvars[j] = Variable(getchildren(m)[scen], Pvar.col)
                end
            end
        end
        m.obj = copy(P.obj, m)
        m.objSense = P.objSense
        #Copy the non-linear objective

	quadobj = false
	if length(m.obj.qvars1)>0
	    quadobj = true
	end
	if P.nlpdata != nothing
        if P.nlpdata.nlobj != nothing  || quadobj # !isobjquadratic(d)&& ! isobjlinear(d)
	    removed = removeConnection(P)
            d = JuMP.NLPEvaluator(P)          #Get the NLP evaluator object.  Initialize the expression graph
            MathProgBase.initialize(d,[:ExprGraph])
            expr = MathProgBase.obj_expr(d)
            JuMP.setNLobjective(m, P.objSense, expr)
	    P.linconstr = [P.linconstr; removed]
        end
	end
    else
        m = copy(P)
    end
    return m
end


#=
function copyModel(P::JuMP.Model)
	m = Model()
        num_vars = P.numCols
        v_map = Array(Int, num_vars)             #this dict will map linear index of the P model variables to the new model JuMP variables {index => JuMP.Variable}
        #add the P model variables to the new model
        for i = 1:num_vars
            @variable(m,P.colLower[i] <= x <= P.colUpper[i])   #just call the new variable x
            var_name = string(Variable(P,i))
            setname(x,var_name)                           #rename the variable to the P model variable name plus the P or edge name
            setcategory(x,P.colCat[i])                            #set the variable to the same category
            setvalue(x,P.colVal[i])                               #set the variable to the same value
            v_map[i] = x.col                                             #map the linear index of the P model variable to the new variable
            m.varDict[Symbol(var_name)] = x
        end
        delete!(m.varDict,:x)

        #copy the linear constraints to the new model
        for i = 1:length(P.linconstr)
            con = P.linconstr[i]
            t = collect(linearterms(con.terms))
            @constraint(m,reference,con.lb <= sum{t[i][1]*v_map[linearindex(t[i][2])],i = 1:length(t)} + con.terms.constant <= con.ub)
            push!(constraints(P),reference)
        end

    	#Copy the non-linear constraints to the new model
    	d = JuMP.NLPEvaluator(P)     #Get the NLP evaluator object.  Initialize the expression graph
    	MathProgBase.initialize(d,[:ExprGraph])
    	num_cons = MathProgBase.numconstr(P)
    	for i = 1:num_cons
        if !(MathProgBase.isconstrlinear(d,i))    #if it's not a linear constraint
            expr = MathProgBase.constr_expr(d,i)  #this returns a julia expression
            _splicevars!(expr,v_map)              #splice the variables from v_map into the expression
            JuMP.addNLconstraint(m,expr)          #raw expression input for non-linear constraint
        end
    end
    return m
end
=#

#splice variables into a constraint expression
function _splicevars!(expr::Expr,v_map::Array{Int64,1})
    for i = 1:length(expr.args)
        if typeof(expr.args[i]) == Expr
            if expr.args[i].head != :ref   #keep calling _splicevars! on the expression until it's a :ref. i.e. :(x[index])
                _splicevars!(expr.args[i],v_map)
            else  #it's a variable
                var_index = expr.args[i].args[2]   #this is the actual index in x[1], x[2], etc...
                new_var = :(x[$(v_map[var_index])])   #get the JuMP variable from v_map using the index
                expr.args[i] = new_var             #replace :(x[index]) with a :(JuMP.Variable)
            end
        end
    end
end


function extractVarsId(expr::Expr)
    varsId = Int[]	 
    for i = 1:length(expr.args)
        if typeof(expr.args[i]) == Expr
            if expr.args[i].head != :ref   #keep calling _splicevars! on the expression until it's a :ref. i.e. :(x[index])
                varsId = [varsId, extractVarsId(expr.args[i])]
            else  #it's a variable
                var_index = expr.args[i].args[2]   #this is the actual index in x[1], x[2], etc...
		return [var_index]
            end
        end
    end
    return union(varsId) 
end

function extractVarsId(vars::Array{Variable,1})
    varsId = Int[]
    for i = 1:length(vars)
    	push!(varsId, vars[i].col)
    end
    return union(varsId)
end




function removeConnection(master::JuMP.Model)
    deleterow = []
    for row in 1:length(master.linconstr)
        coeffs = master.linconstr[row].terms.coeffs
        vars   = master.linconstr[row].terms.vars
        for (it,ind) in enumerate(coeffs)
            if (vars[it].m) != master
                push!(deleterow, row)
                break
            end
        end
    end
    deleted = master.linconstr[deleterow]
    deleteat!(master.linconstr,deleterow)
    return deleted
end




end
include("NetParPipsNlp.jl")
include("NetIpopt.jl")
#end



