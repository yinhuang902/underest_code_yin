"""
Collector class that keeps track of per - iteration information.
Intended for plotting purposes.
"""
from pyomo.common.numeric_types import native_numeric_types

class PlotScraper():
    """
    Tracks relevant per-iter information.
    """

    def __init__(self) -> None:
        """
        Initializes all of the tracked information.

        Parameters 
        -----------
        subproblem_names : list[str]
            list of string subproblem names
        max_iters : int
            maximum number of allowable iterations
        """
        self.iter_lb = []
        self.iter_ub = []


    def iter_update(self, lb, ub):
        """
        At an iteration, update.

        Parameters
        ----------
        iter : int
            iter number
        lb : float
            float value of aggregated lb objective
        ub : float
            float value of aggregated ub objective
        ub_solution : dict
            full solution of the upper bounding solution
        node_state : dict
            current BnB node state
        """
        assert type(lb) in native_numeric_types
        self.iter_lb.append(lb)
        assert type(ub) in native_numeric_types
        self.iter_ub.append(ub)